import { motion } from 'framer-motion'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { BookOpen, TrendingUp, DollarSign } from 'lucide-react'

const mockData = [
  { day: 'Mon', value: 100 },
  { day: 'Tue', value: 120 },
  { day: 'Wed', value: 140 },
  { day: 'Thu', value: 160 },
  { day: 'Fri', value: 180 },
]

export default function InvestLearnApp() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-white p-6">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold text-indigo-700">Invest & Learn</h1>
        <p className="text-slate-600">Earn rewards while learning about money</p>
      </header>

      <main className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        {/* Learning Section */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow-md flex flex-col gap-4"
        >
          <div className="flex items-center gap-2 text-indigo-600 font-semibold">
            <BookOpen className="w-5 h-5" /> Learn Module
          </div>
          <p className="text-slate-700">
            Discover how investing works with bite-sized lessons.
          </p>
          <button className="bg-indigo-600 text-white px-4 py-2 rounded-xl shadow hover:bg-indigo-700">
            Start Lesson
          </button>
        </motion.div>

        {/* Investment Growth Section */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow-md flex flex-col gap-4"
        >
          <div className="flex items-center gap-2 text-green-600 font-semibold">
            <TrendingUp className="w-5 h-5" /> Simulated Growth
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={mockData}>
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#4f46e5" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Rewards Section */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow-md flex flex-col gap-4 col-span-full"
        >
          <div className="flex items-center gap-2 text-yellow-600 font-semibold">
            <DollarSign className="w-5 h-5" /> Rewards
          </div>
          <p className="text-slate-700">Complete lessons to earn points you can redeem.</p>
          <div className="flex gap-2">
            <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm">
              1200 Points
            </span>
            <button className="bg-yellow-500 text-white px-4 py-2 rounded-xl shadow hover:bg-yellow-600">
              Redeem
            </button>
          </div>
        </motion.div>
      </main>
    </div>
  )
}